//
//  iOS development Course
//  by Oleksandr Slobodianiuk
//

import UIKit

var greeting = "Hello!"
greeting = "Some text"
greeting = "123"
//print(greeting)

var myBestFriedsGreeting = "Hey bro!"

let name: String = "Bob"
var age: Int = 28
var isMerried = true
age = 10

isMerried = false

var a = 10
var b = 15

let sum = a + b
let mult = a * b
let myLine = "Sum is - \(sum), multiply result is - \(mult)!!!"
//print(myLine)

//print("Number of simbols in my line is: \(myLine.count)")

isMerried.toggle()
print(isMerried)
